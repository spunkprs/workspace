package com.prateek.thoughtworkscodingassignment;

/*Base class for every rule.*/

public abstract class Rule {

	public abstract boolean validate(final int i, final char arr[]);
}
